import { NextResponse } from "next/server";

export async function POST(req: Request){
  // This is a placeholder API. Wire to your email service / CRM as needed.
  const body = await req.text();
  console.log("Contact form submission:", body);
  return NextResponse.json({ ok: true });
}
