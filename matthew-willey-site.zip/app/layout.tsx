import type { Metadata } from "next";
import "./globals.css";
import { Inter } from "next/font/google";

const inter = Inter({ subsets: ["latin"] });

export const metadata: Metadata = {
  title: "Matthew Willey — Tech + Marketing Strategist",
  description: "Turning complex technology into simple solutions for small business growth.",
  metadataBase: new URL("https://example.com"), // TODO: replace with your domain
  openGraph: {
    title: "Matthew Willey — Tech + Marketing Strategist",
    description: "Turning complex technology into simple solutions for small business growth.",
    url: "https://example.com",
    siteName: "Matthew Willey",
    images: [{ url: "/images/profile.svg", width: 1200, height: 630 }],
    locale: "en_US",
    type: "website",
  },
  twitter: {
    card: "summary_large_image",
    title: "Matthew Willey — Tech + Marketing Strategist",
    description: "Turning complex technology into simple solutions for small business growth.",
    images: ["/images/profile.svg"],
    creator: "@yourhandle"
  },
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  const ld = {
    "@context":"https://schema.org",
    "@type":"Person",
    "name":"Matthew Willey",
    "jobTitle":"Tech + Marketing Strategist",
    "url":"https://example.com",
    "sameAs": []
  };

  return (
    <html lang="en">
      <body className={inter.className}>
        <script
          type="application/ld+json"
          dangerouslySetInnerHTML={{ __html: JSON.stringify(ld) }}
        />
        {children}
      </body>
    </html>
  );
}
