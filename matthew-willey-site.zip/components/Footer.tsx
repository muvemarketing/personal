export default function Footer(){
  return (
    <footer className="bg-[color:var(--navy)]/70 border-t border-white/5">
      <div className="mx-auto max-w-6xl px-6 py-10 text-sm text-softGray flex flex-col md:flex-row items-center justify-between gap-4">
        <p>© 2025 Matthew Willey | Built with love + neon.</p>
        <nav className="flex items-center gap-5">
          <a className="link-glow" href="#" aria-label="LinkedIn">LinkedIn</a>
          <a className="link-glow" href="mailto:hello@example.com" aria-label="Email">Email</a>
        </nav>
      </div>
    </footer>
  );
}
