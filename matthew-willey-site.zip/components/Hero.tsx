import Link from "next/link";

export default function Hero(){
  return (
    <section className="relative overflow-hidden bg-navy">
      <div className="absolute inset-0 mesh-bg opacity-70"></div>
      <div className="relative mx-auto max-w-6xl px-6 pt-28 pb-24 text-center">
        <h1 className="text-4xl md:text-6xl font-extrabold tracking-tight text-white">
          Turning complex technology into simple solutions for small business growth.
        </h1>
        <p className="mt-6 text-lg md:text-xl text-softGray max-w-3xl mx-auto">
          I help businesses bridge the gap between everyday operations and modern digital tools — building smarter websites, automations,
          and marketing systems that actually drive results.
        </p>
        <div className="mt-10 flex items-center justify-center gap-4">
          <Link href="#contact" className="btn btn-primary">Work With Me</Link>
          <Link href="#portfolio" className="btn btn-outline">See My Work</Link>
        </div>
      </div>
    </section>
  );
}
