const skills: Record<string, string[]> = {
  "Development & Platforms": ["HTML5 / CSS3", "JavaScript (ES6+)", "PHP", "WordPress (Elementor, Divi, Gutenberg)", "Shopify", "WooCommerce", "Wix", "Squarespace", "SharePoint"],
  "Automation & Productivity": ["Google Workspace Automation", "Zapier", "HubSpot Automation", "Salesforce CRM", "Airtable", "Asana", "Trello", "Monday.com", "Slack Integrations"],
  "AI & Emerging Tech": ["ChatGPT", "Google Gemini"],
  "Marketing & Analytics": ["GA4", "Google Tag Manager", "Google Ads", "Facebook Ads Manager", "LinkedIn Ads", "HubSpot Marketing Hub", "Mailchimp", "Constant Contact", "Klaviyo", "Hotjar", "Crazy Egg", "SEMrush", "Ahrefs", "Moz"],
  "Design & Creative": ["Adobe Photoshop", "Illustrator", "InDesign"],
  "Security & Infrastructure": ["Google Cloud Platform", "SSL & HTTPS Management", "Cloudflare"],
  "Data & Reporting": ["Excel (Advanced, PivotTables, VBA)"],
};

export default function Skills(){
  return (
    <section id="skills" className="section">
      <div className="mx-auto max-w-6xl px-6">
        <h2 className="text-3xl md:text-4xl font-bold mb-10">Skills & Software</h2>
        <div className="grid md:grid-cols-2 gap-6">
          {Object.entries(skills).map(([category, items]) => (
            <div key={category} className="card card-hover card-glow">
              <h3 className="text-lg font-semibold text-white">{category}</h3>
              <ul className="mt-3 grid grid-cols-1 sm:grid-cols-2 gap-2 text-sm">
                {items.map((it) => (
                  <li key={it} className="text-softGray">• {it}</li>
                ))}
              </ul>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
