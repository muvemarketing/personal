import Image from "next/image";

type Case = {
  title: string;
  image: string;
  challenge: string;
  solution: string;
  results: string;
};

const cases: Case[] = [
  {
    title: "Saints Peter & Paul Schools",
    image: "/images/portfolio-spps.svg",
    challenge: "Outdated websites across three schools.",
    solution: "Redesigned with modern UX + SEO.",
    results: "Unified branding + improved navigation."
  },
  {
    title: "Campos Media",
    image: "/images/portfolio-campos.svg",
    challenge: "Needed modern site for photography/videography.",
    solution: "Responsive site with gallery.",
    results: "Professional showcase driving leads."
  },
  {
    title: "MD Lands (Jay Phillips)",
    image: "/images/portfolio-mdlands.svg",
    challenge: "Increase traffic, redesign site.",
    solution: "SEO + Houzez WordPress theme.",
    results: "Boosted traffic and engagement."
  },
  {
    title: "Black Lab Leather Goods",
    image: "/images/portfolio-bllg.svg",
    challenge: "Strengthen e-commerce brand.",
    solution: "Branding + SEO + marketing.",
    results: "Greater visibility and online reach."
  },
];

export default function Portfolio(){
  return (
    <section id="portfolio" className="section bg-[color:var(--navy)]/40">
      <div className="mx-auto max-w-6xl px-6">
        <h2 className="text-3xl md:text-4xl font-bold text-white">Portfolio / Case Studies</h2>
        <p className="mt-2 text-softGray">A look at some of the businesses I’ve helped grow through technology, marketing, and automation.</p>
        <div className="mt-8 grid md:grid-cols-2 gap-6">
          {cases.map((c) => (
            <article key={c.title} className="card card-hover card-glow">
              <div className="overflow-hidden rounded-lg">
                <Image src={c.image} alt={c.title} width={960} height={540} className="w-full h-auto" />
              </div>
              <h3 className="mt-4 text-xl font-semibold text-white">{c.title}</h3>
              <ul className="mt-3 space-y-1 text-sm">
                <li><span className="text-white">Challenge:</span> {c.challenge}</li>
                <li><span className="text-white">Solution:</span> {c.solution}</li>
                <li><span className="text-white">Results:</span> {c.results}</li>
              </ul>
            </article>
          ))}
        </div>
      </div>
    </section>
  );
}
