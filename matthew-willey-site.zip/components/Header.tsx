import Link from "next/link";

const NavLink = ({ href, children }: { href: string; children: React.ReactNode }) => (
  <Link className="text-softGray hover:text-white transition-colors" href={href}>
    {children}
  </Link>
);

export default function Header() {
  return (
    <header className="sticky top-0 z-50 backdrop-blur supports-[backdrop-filter]:bg-navy/60 bg-navy/80 border-b border-white/5">
      <div className="mx-auto max-w-6xl px-6 py-4 flex items-center justify-between">
        <Link href="#" className="text-white font-semibold tracking-tight">
          <span className="text-cyanNeon">Matthew</span> Willey
        </Link>
        <nav className="flex items-center gap-6 text-sm">
          <NavLink href="#about">About</NavLink>
          <NavLink href="#experience">Experience</NavLink>
          <NavLink href="#skills">Skills</NavLink>
          <NavLink href="#portfolio">Portfolio</NavLink>
          <NavLink href="#contact">Contact</NavLink>
        </nav>
      </div>
    </header>
  );
}
