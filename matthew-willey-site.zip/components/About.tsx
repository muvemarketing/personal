import Image from "next/image";

export default function About(){
  return (
    <section id="about" className="section bg-charcoal">
      <div className="mx-auto max-w-6xl px-6 grid md:grid-cols-2 gap-10 items-center">
        <div className="relative">
          <div className="absolute -inset-1 rounded-2xl blur opacity-60" style={{ background: "linear-gradient(90deg, rgba(0,212,255,0.5), rgba(154,48,238,0.45))" }}></div>
          <div className="relative rounded-2xl overflow-hidden">
            <Image src="/images/profile.svg" alt="Matthew Willey" width={640} height={640} className="w-full h-auto" priority />
          </div>
        </div>
        <div>
          <h2 className="text-3xl md:text-4xl font-bold">Hi, I’m Matthew Willey.</h2>
          <p className="mt-5 leading-relaxed">
            I’m a 32-year-old tech enthusiast and entrepreneur passionate about helping businesses unlock the full potential of technology. Over the past decade,
            I’ve built a career at the intersection of web development, marketing, and automation, working with companies of all sizes to streamline operations,
            boost their online presence, and drive measurable growth.
          </p>
          <p className="mt-4 leading-relaxed">
            I built my first website in Microsoft Publisher at age 8. That early curiosity sparked a lifelong passion for blending logic and design—the technical side of coding with the creative side of branding.
          </p>
          <p className="mt-4 leading-relaxed">
            Today, I’m the Owner of Muve Marketing (2023–present), helping businesses in home services, retail, restaurants, real estate, and professional services. Previously, I was President of Spider Web Connections (2018–2023).
          </p>
          <p className="mt-4 leading-relaxed">
            Outside of work, you’ll find me fishing, playing pool, watching wrestling, or cheering on the Philadelphia Eagles 🦅.
          </p>
          <p className="mt-4 leading-relaxed">
            At my core, I love solving problems with technology—whether it’s designing a website, automating workflows, or building a marketing campaign that converts.
          </p>
        </div>
      </div>
    </section>
  );
}
