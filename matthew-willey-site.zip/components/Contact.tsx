"use client";

import { useState } from "react";

export default function Contact(){
  const [status, setStatus] = useState<null | "idle" | "sending" | "sent" | "error">(null);

  async function onSubmit(e: React.FormEvent<HTMLFormElement>){
    e.preventDefault();
    const form = e.currentTarget;
    const formData = new FormData(form);
    const payload = Object.fromEntries(formData.entries());
    setStatus("sending");
    try {
      const res = await fetch("/api/contact", { method: "POST", body: JSON.stringify(payload) });
      if (res.ok) {
        setStatus("sent");
        form.reset();
      } else {
        setStatus("error");
      }
    } catch {
      setStatus("error");
    }
  }

  return (
    <section id="contact" className="section relative overflow-hidden">
      <div className="absolute inset-0 mesh-bg opacity-60"></div>
      <div className="relative mx-auto max-w-6xl px-6">
        <h2 className="text-3xl md:text-4xl font-bold text-white">Contact</h2>
        <p className="mt-2 text-softGray max-w-2xl">
          Ready to build something great? Send a note and I’ll get back to you.
        </p>

        <form onSubmit={onSubmit} className="mt-8 grid md:grid-cols-2 gap-6">
          <div className="md:col-span-1">
            <label className="block text-sm text-softGray mb-2">Name</label>
            <input name="name" required placeholder="Your name" className="w-full rounded-md bg-white/5 border border-white/10 px-4 py-3 text-white placeholder-softGray focus:outline-none focus:ring-2 focus:ring-cyanNeon" />
          </div>
          <div className="md:col-span-1">
            <label className="block text-sm text-softGray mb-2">Email</label>
            <input name="email" type="email" required placeholder="you@example.com" className="w-full rounded-md bg-white/5 border border-white/10 px-4 py-3 text-white placeholder-softGray focus:outline-none focus:ring-2 focus:ring-cyanNeon" />
          </div>
          <div className="md:col-span-2">
            <label className="block text-sm text-softGray mb-2">Message</label>
            <textarea name="message" required rows={5} placeholder="Tell me a bit about your project..." className="w-full rounded-md bg-white/5 border border-white/10 px-4 py-3 text-white placeholder-softGray focus:outline-none focus:ring-2 focus:ring-cyanNeon"></textarea>
          </div>
          <div className="md:col-span-2 flex items-center gap-4">
            <button className="btn btn-primary" disabled={status === "sending"}>
              {status === "sending" ? "Sending..." : "Send Message"}
            </button>
            <a className="link-glow" href="mailto:hello@example.com">Or email me directly</a>
          </div>
          {status === "sent" && <p className="text-greenNeon">Thanks! Your message was sent.</p>}
          {status === "error" && <p className="text-orangeNeon">Something went wrong. Try again or use the email link.</p>}
        </form>

        {/* Optional: Calendly embed (replace with your scheduling link)
        <div className="mt-10">
          <iframe title="Schedule with Matthew" src="https://calendly.com/YOUR_HANDLE/intro-call" className="w-full h-[700px] rounded-xl border border-white/10"></iframe>
        </div> */}
      </div>
    </section>
  );
}
