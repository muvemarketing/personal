import Link from "next/link";

const roles = [
  { title: "Owner — Muve Marketing", where: "Bethany Beach, DE", when: "July 2023 – Present" },
  { title: "President — Spider Web Connections", where: "", when: "2018 – 2023" },
  { title: "CEO & Creative Director — Archaea, LLC", where: "", when: "Feb 2016 – Present" },
  { title: "SharePoint Consultant — Trellist Marketing Technology", where: "", when: "Oct 2015 – May 2016" },
  { title: "Business Analyst — Bridgeforce, Inc", where: "", when: "Dec 2013 – Sep 2015" },
  { title: "Assistant to COO — White Optics, LLC", where: "", when: "Jun 2013 – Aug 2013" },
];

export default function Experience(){
  return (
    <section id="experience" className="section bg-[color:var(--navy)]/50">
      <div className="mx-auto max-w-6xl px-6">
        <div className="flex items-center justify-between mb-10">
          <h2 className="text-3xl md:text-4xl font-bold">Experience</h2>
          <Link href="/resume.pdf" className="btn btn-outline" download>Download Résumé (PDF)</Link>
        </div>

        <div className="timeline space-y-10">
          {roles.map((r, i) => (
            <div key={i} className="relative pl-6">
              <span className="timeline-dot" style={{ top: "0.35rem" }}></span>
              <h3 className="text-xl font-semibold text-white">{r.title}</h3>
              <p className="text-softGray">{[r.where, r.when].filter(Boolean).join(" | ")}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
